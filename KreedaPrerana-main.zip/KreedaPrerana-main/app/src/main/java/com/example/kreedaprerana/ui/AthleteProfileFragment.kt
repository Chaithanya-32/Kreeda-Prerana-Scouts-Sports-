package com.example.kreedaprerana.ui

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.kreedaprerana.data.Trial
import com.example.kreedaprerana.utils.BadgeEvaluator
import com.example.kreedaprerana.viewmodel.KreedaViewModel
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.example.kreedaprerana.R

class AthleteProfileFragment : Fragment(R.layout.fragment_athlete_profile) {

    private val viewModel: KreedaViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val athleteId = arguments?.getInt("athleteId") ?: return

        val tvName = view.findViewById<TextView>(R.id.tvAthleteName)
        val tvInfo = view.findViewById<TextView>(R.id.tvAthleteInfo)
        val tvBadge = view.findViewById<TextView>(R.id.tvBadge)
        val chart = view.findViewById<LineChart>(R.id.talentCurveChart)
        val btnLog = view.findViewById<Button>(R.id.btnLogTrial)

        viewModel.allAthletes.observe(viewLifecycleOwner) { athletes ->
            val athlete = athletes.find { it.id == athleteId }
            athlete?.let {
                tvName.text = it.name
                tvInfo.text = "${it.sport} | Age ${it.age} | ${it.school}"
            }
        }

        viewModel.getTrialsFor(athleteId).observe(viewLifecycleOwner) { trials ->
            if (trials.isNotEmpty()) {
                val entries = trials.mapIndexed { i, t ->
                    Entry(i.toFloat(), t.value.toFloat())
                }
                val dataSet = LineDataSet(entries, "Performance").apply {
                    lineWidth = 2f
                    circleRadius = 4f
                    valueTextSize = 10f
                }
                chart.data = LineData(dataSet)
                chart.description.text = "Talent Curve"
                chart.animateX(800)
                chart.invalidate()

                val badge = BadgeEvaluator.evaluate(
                    trials.last().trialType,
                    trials.last().value
                )
                tvBadge.text = badge ?: ""
            }
        }

        btnLog.setOnClickListener { showLogDialog(athleteId) }
    }

    private fun showLogDialog(athleteId: Int) {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 20)
        }
        val etType = EditText(requireContext()).apply {
            hint = "Trial type (e.g. 100m Sprint)"
        }
        val etValue = EditText(requireContext()).apply {
            hint = "Value (seconds or meters)"
            inputType = InputType.TYPE_CLASS_NUMBER or
                    InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        layout.addView(etType)
        layout.addView(etValue)

        AlertDialog.Builder(requireContext())
            .setTitle("Log Trial")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val type = etType.text.toString()
                val value = etValue.text.toString().toDoubleOrNull() ?: 0.0
                val unit = if (type.contains("Jump")) "m" else "sec"
                viewModel.logTrial(
                    Trial(
                        athleteId = athleteId,
                        trialType = type,
                        value = value,
                        unit = unit
                    )
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}