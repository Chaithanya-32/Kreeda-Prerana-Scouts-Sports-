package com.example.kreedaprerana.utils

object BadgeEvaluator {

    private val benchmarks = mapOf(
        "100m Sprint" to 14.0,
        "200m Sprint" to 30.0,
        "Long Jump" to 4.0,
        "High Jump" to 1.2
    )

    fun evaluate(trialType: String, value: Double): String? {
        val benchmark = benchmarks[trialType] ?: return null
        return when (trialType) {
            "100m Sprint", "200m Sprint" ->
                if (value <= benchmark) "🏅 District Level Ready!" else null
            "Long Jump", "High Jump" ->
                if (value >= benchmark) "🏅 District Level Ready!" else null
            else -> null
        }
    }
}