package com.example.kreedaprerana.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Athlete::class, Trial::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun athleteDao(): AthleteDao
    abstract fun trialDao(): TrialDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kreeda_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}