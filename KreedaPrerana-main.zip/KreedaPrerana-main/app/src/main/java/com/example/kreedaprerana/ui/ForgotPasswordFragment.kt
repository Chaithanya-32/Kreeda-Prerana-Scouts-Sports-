package com.example.kreedaprerana.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.kreedaprerana.R

class ForgotPasswordFragment : Fragment(R.layout.fragment_forgot_password) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etUsername = view.findViewById<EditText>(R.id.etResetUsername)
        val etNewPass = view.findViewById<EditText>(R.id.etNewPass)
        val btnReset = view.findViewById<Button>(R.id.btnResetPassword)
        val tvMsg = view.findViewById<TextView>(R.id.tvResetMsg)
        val tvBack = view.findViewById<TextView>(R.id.tvBackToLoginFromReset)

        btnReset.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val newPass = etNewPass.text.toString().trim()

            val prefs = requireContext()
                .getSharedPreferences("kreeda_users", Context.MODE_PRIVATE)

            when {
                username.isEmpty() -> {
                    tvMsg.setTextColor(android.graphics.Color.RED)
                    tvMsg.text = "❌ Enter username"
                }
                newPass.length < 6 -> {
                    tvMsg.setTextColor(android.graphics.Color.RED)
                    tvMsg.text = "❌ Password min 6 characters"
                }
                !prefs.contains(username) && username != "admin" -> {
                    tvMsg.setTextColor(android.graphics.Color.RED)
                    tvMsg.text = "❌ Username not found"
                }
                else -> {
                    prefs.edit().putString(username, newPass).apply()
                    tvMsg.setTextColor(
                        android.graphics.Color.parseColor("#4CAF50")
                    )
                    tvMsg.text = "✅ Password reset! Please login"
                    view.postDelayed({
                        findNavController().navigateUp()
                    }, 1500)
                }
            }
        }

        tvBack.setOnClickListener {
            findNavController().navigateUp()
        }
    }
}