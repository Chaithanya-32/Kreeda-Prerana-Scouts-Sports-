package com.example.kreedaprerana.repository

import com.example.kreedaprerana.data.AppDatabase
import com.example.kreedaprerana.data.Athlete
import com.example.kreedaprerana.data.Trial
import com.example.kreedaprerana.data.AthleteDao
import com.example.kreedaprerana.data.TrialDao

class KreedaRepository(
    private val athleteDao: AthleteDao,
    private val trialDao: TrialDao
) {
    val allAthletes = athleteDao.getAllAthletes()

    suspend fun insertAthlete(athlete: Athlete) =
        athleteDao.insert(athlete)

    suspend fun deleteAthlete(athlete: Athlete) =
        athleteDao.delete(athlete)

    suspend fun insertTrial(trial: Trial) =
        trialDao.insert(trial)

    fun getTrialsForAthlete(id: Int) =
        trialDao.getTrialsForAthlete(id)

    fun getAllTrials() =
        trialDao.getAllTrials()
}