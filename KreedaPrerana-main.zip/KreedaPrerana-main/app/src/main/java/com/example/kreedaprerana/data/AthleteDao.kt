package com.example.kreedaprerana.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AthleteDao {

    @Insert
    suspend fun insert(athlete: Athlete): Long

    @Delete
    suspend fun delete(athlete: Athlete)

    @Query("SELECT * FROM athletes ORDER BY name ASC")
    fun getAllAthletes(): LiveData<List<Athlete>>

    @Query("SELECT * FROM athletes WHERE id = :id")
    suspend fun getById(id: Int): Athlete?
}