package com.example.kreedaprerana.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.kreedaprerana.R

class SignUpFragment : Fragment(R.layout.fragment_signup) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etFullName = view.findViewById<EditText>(R.id.etFullName)
        val etUsername = view.findViewById<EditText>(R.id.etNewUsername)
        val etPassword = view.findViewById<EditText>(R.id.etNewPassword)
        val etConfirm = view.findViewById<EditText>(R.id.etConfirmPassword)
        val btnSignUp = view.findViewById<Button>(R.id.btnSignUp)
        val tvError = view.findViewById<TextView>(R.id.tvSignUpError)
        val tvBack = view.findViewById<TextView>(R.id.tvBackToLogin)

        btnSignUp.setOnClickListener {
            val name = etFullName.text.toString().trim()
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()
            val confirm = etConfirm.text.toString().trim()

            when {
                name.isEmpty() -> tvError.text = "❌ Enter full name"
                username.isEmpty() -> tvError.text = "❌ Enter username"
                password.length < 6 -> tvError.text = "❌ Password min 6 characters"
                password != confirm -> tvError.text = "❌ Passwords don't match"
                else -> {
                    // Save to SharedPreferences
                    val prefs = requireContext()
                        .getSharedPreferences("kreeda_users", Context.MODE_PRIVATE)
                    if (prefs.contains(username)) {
                        tvError.text = "❌ Username already exists"
                    } else {
                        prefs.edit().putString(username, password).apply()
                        tvError.setTextColor(
                            android.graphics.Color.parseColor("#4CAF50")
                        )
                        tvError.text = "✅ Account created! Please login"
                        // Go back to login after 1 second
                        view.postDelayed({
                            findNavController().navigateUp()
                        }, 1500)
                    }
                }
            }
        }

        tvBack.setOnClickListener {
            findNavController().navigateUp()
        }
    }
}