package com.example.kreedaprerana.ui

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kreedaprerana.viewmodel.KreedaViewModel
import com.example.kreedaprerana.R

class LeaderboardFragment : Fragment(R.layout.fragment_leaderboard) {

    private val viewModel: KreedaViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerLeaderboard)

        val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            var items = listOf<Pair<Int, Double>>()
            inner class VH(v: View) : RecyclerView.ViewHolder(v)

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
                val tv = TextView(parent.context).apply {
                    textSize = 16f
                    setPadding(16, 20, 16, 20)
                }
                return VH(tv)
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
                val (athleteId, best) = items[pos]
                (holder.itemView as TextView).text =
                    "${pos + 1}. Athlete #$athleteId  —  Best: $best"
            }

            override fun getItemCount() = items.size
        }

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        viewModel.getAllTrials().observe(viewLifecycleOwner) { trials ->
            val ranked = trials
                .groupBy { it.athleteId }
                .map { (id, list) -> id to list.minOf { it.value } }
                .sortedBy { it.second }
            adapter.items = ranked
            adapter.notifyDataSetChanged()
        }
    }
}