package com.example.kreedaprerana.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface TrialDao {

    @Insert
    suspend fun insert(trial: Trial)

    @Query("SELECT * FROM trials WHERE athleteId = :id ORDER BY timestamp ASC")
    fun getTrialsForAthlete(id: Int): LiveData<List<Trial>>

    @Query("SELECT * FROM trials ORDER BY timestamp DESC")
    fun getAllTrials(): LiveData<List<Trial>>
}