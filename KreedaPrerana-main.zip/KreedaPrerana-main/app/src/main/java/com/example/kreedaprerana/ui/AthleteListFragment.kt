package com.example.kreedaprerana.ui

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.kreedaprerana.R
import com.example.kreedaprerana.data.Athlete
import com.example.kreedaprerana.viewmodel.KreedaViewModel

class AthleteListFragment : Fragment(R.layout.fragment_athlete_list) {

    private val viewModel: KreedaViewModel by activityViewModels()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        val fabAdd = view.findViewById<View>(R.id.fabAddAthlete)
        val btnTimer = view.findViewById<View>(R.id.btnTimer)
        val btnLeaderboard = view.findViewById<View>(R.id.btnLeaderboard)
        val etSearch = view.findViewById<EditText>(R.id.etSearch)

        // Track full list for search filtering
        var allAthletes = listOf<Athlete>()

        val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            var athletes = listOf<Athlete>()
            inner class VH(v: View) : RecyclerView.ViewHolder(v)

            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
                val card = androidx.cardview.widget.CardView(parent.context).apply {
                    radius = 16f
                    cardElevation = 6f
                    setCardBackgroundColor(android.graphics.Color.WHITE)
                    layoutParams = ViewGroup.MarginLayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(8, 8, 8, 8) }
                }
                val tv = TextView(parent.context).apply {
                    textSize = 16f
                    setTextColor(android.graphics.Color.parseColor("#212121"))
                    setPadding(32, 28, 32, 28)
                }
                card.addView(tv)
                return VH(card)
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, pos: Int) {
                val a = athletes[pos]
                val card = holder.itemView as androidx.cardview.widget.CardView
                val tv = card.getChildAt(0) as TextView
                tv.text = "👤 ${a.name}\n🏃 ${a.sport}  •  Age ${a.age}  •  ${a.school}"
                card.setOnClickListener {
                    val bundle = Bundle().apply { putInt("athleteId", a.id) }
                    findNavController().navigate(R.id.action_list_to_profile, bundle)
                }
            }

            override fun getItemCount() = athletes.size
        }

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = adapter

        // Observe athletes
        viewModel.allAthletes.observe(viewLifecycleOwner) {
            allAthletes = it
            adapter.athletes = it
            adapter.notifyDataSetChanged()
        }

        // 🔍 Search logic
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().lowercase().trim()
                adapter.athletes = if (query.isEmpty()) {
                    allAthletes
                } else {
                    allAthletes.filter {
                        it.name.lowercase().contains(query) ||
                                it.sport.lowercase().contains(query) ||
                                it.school.lowercase().contains(query)
                    }
                }
                adapter.notifyDataSetChanged()
            }
        })

        fabAdd.setOnClickListener { showAddDialog() }
        btnTimer.setOnClickListener {
            findNavController().navigate(R.id.action_list_to_timer)
        }
        btnLeaderboard.setOnClickListener {
            findNavController().navigate(R.id.action_list_to_leaderboard)
        }
    }

    private fun showAddDialog() {
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 20)
        }
        val etName = EditText(requireContext()).apply { hint = "Name" }
        val etAge = EditText(requireContext()).apply {
            hint = "Age"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val etSport = EditText(requireContext()).apply { hint = "Sport" }
        val etSchool = EditText(requireContext()).apply { hint = "School" }
        layout.addView(etName)
        layout.addView(etAge)
        layout.addView(etSport)
        layout.addView(etSchool)

        AlertDialog.Builder(requireContext())
            .setTitle("Add Athlete")
            .setView(layout)
            .setPositiveButton("Add") { _, _ ->
                val name = etName.text.toString()
                val age = etAge.text.toString().toIntOrNull() ?: 0
                val sport = etSport.text.toString()
                val school = etSchool.text.toString()
                if (name.isNotEmpty()) {
                    viewModel.addAthlete(
                        Athlete(name = name, age = age,
                            sport = sport, school = school)
                    )
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}