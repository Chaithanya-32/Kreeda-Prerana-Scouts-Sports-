package com.example.kreedaprerana.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trials")
data class Trial(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val athleteId: Int,
    val trialType: String,
    val value: Double,
    val unit: String,
    val timestamp: Long = System.currentTimeMillis()
)