package com.example.kreedaprerana.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.kreedaprerana.data.AppDatabase
import com.example.kreedaprerana.data.Athlete
import com.example.kreedaprerana.data.Trial
import com.example.kreedaprerana.repository.KreedaRepository
import kotlinx.coroutines.launch

class KreedaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repo = KreedaRepository(db.athleteDao(), db.trialDao())

    val allAthletes = repo.allAthletes

    fun addAthlete(athlete: Athlete) = viewModelScope.launch {
        repo.insertAthlete(athlete)
    }

    fun deleteAthlete(athlete: Athlete) = viewModelScope.launch {
        repo.deleteAthlete(athlete)
    }

    fun logTrial(trial: Trial) = viewModelScope.launch {
        repo.insertTrial(trial)
    }

    fun getTrialsFor(athleteId: Int) =
        repo.getTrialsForAthlete(athleteId)

    fun getAllTrials() =
        repo.getAllTrials()
}