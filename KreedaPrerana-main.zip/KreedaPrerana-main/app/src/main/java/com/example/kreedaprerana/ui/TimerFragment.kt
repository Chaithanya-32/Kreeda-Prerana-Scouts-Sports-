package com.example.kreedaprerana.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.kreedaprerana.R

class TimerFragment : Fragment(R.layout.fragment_timer) {

    private var startTime = 0L
    private var running = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var tvTimer: TextView
    private lateinit var btnStart: Button
    private lateinit var btnReset: Button

    private val updateRunnable = object : Runnable {
        override fun run() {
            val elapsed = System.currentTimeMillis() - startTime
            val seconds = elapsed / 1000
            val millis = (elapsed % 1000) / 10
            tvTimer.text = String.format("%02d.%02d", seconds, millis)
            handler.postDelayed(this, 10)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvTimer = view.findViewById(R.id.tvTimer)
        btnStart = view.findViewById(R.id.btnStart)
        btnReset = view.findViewById(R.id.btnReset)

        btnStart.setOnClickListener {
            if (!running) {
                startTime = System.currentTimeMillis()
                handler.post(updateRunnable)
                running = true
                btnStart.text = "Stop"
            } else {
                handler.removeCallbacks(updateRunnable)
                running = false
                btnStart.text = "Start"
            }
        }

        btnReset.setOnClickListener {
            handler.removeCallbacks(updateRunnable)
            running = false
            tvTimer.text = "00.00"
            btnStart.text = "Start"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(updateRunnable)
    }
}