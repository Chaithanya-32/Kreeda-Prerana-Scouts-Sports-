package com.example.kreedaprerana.ui

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.kreedaprerana.R

class LoginFragment : Fragment(R.layout.fragment_login) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etUsername = view.findViewById<EditText>(R.id.etUsername)
        val etPassword = view.findViewById<EditText>(R.id.etPassword)
        val btnLogin = view.findViewById<Button>(R.id.btnLogin)
        val tvError = view.findViewById<TextView>(R.id.tvError)
        val tvForgot = view.findViewById<TextView>(R.id.tvForgotPassword)
        val tvSignUp = view.findViewById<TextView>(R.id.tvSignUp)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            // Check default admin
            val isAdmin = username == "admin" && password == "kreeda123"

            // Check SharedPreferences users
            val prefs = requireContext()
                .getSharedPreferences("kreeda_users", Context.MODE_PRIVATE)
            val savedPass = prefs.getString(username, null)
            val isRegistered = savedPass != null && savedPass == password

            if (isAdmin || isRegistered) {
                findNavController().navigate(R.id.action_login_to_athleteList)
            } else {
                tvError.text = "❌ Invalid username or password"
                etPassword.text.clear()
            }
        }

        tvForgot.setOnClickListener {
            findNavController().navigate(R.id.action_login_to_forgot)
        }

        tvSignUp.setOnClickListener {
            findNavController().navigate(R.id.action_login_to_signup)
        }
    }
}